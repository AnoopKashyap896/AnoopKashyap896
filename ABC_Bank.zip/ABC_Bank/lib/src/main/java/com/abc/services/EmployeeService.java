package com.abc.services;

import java.util.Optional;

import com.abc.entities.Employee;

public interface EmployeeService {
	public void addEmployee(Employee employee);

	public Employee updateEmployee(Employee employee);

	public Optional<Employee> getEmployeeById(int empId);

	public boolean adminLogin(Employee employee);

    public boolean ladLogin(Employee employee);

}
