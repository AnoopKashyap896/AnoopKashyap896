package com.abc.entities;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity

public class Customer {
	@Id
	@Column(name = "CUSTOMER_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer customerId;

	@Column(name = "CUSTOMER_NAME", length = 50)
	@NotBlank(message = "Customer Name is Mandatory")
	private String customerName;

	@Column(name = "PHONE_NUMBER")
	@Pattern(regexp = "[6-9][0-9]{9}", message = "Incorrect Format of Phone Number")
	@NotBlank(message = "Phone_Number is Mandatory")
	private String phoneNumber;

	@Column(name = "EMAIL_ID")
	@Pattern(regexp = "[A-Za-z0-9+_.-]+@(.+)", message = "Incorrect Format of email Id")
	@NotBlank(message = "Email ID is Mandatory")
	private String emailId;

	@Column(name = "SALARY")
	@NotNull(message = "Salary is Mandatory")
	private double salary;

	@Column(name = "OCCUPATION")
	@NotBlank(message = "Occupation is Mandatory")
	private String occupation;

	@Column(name = "GOVT_ID")
	@Pattern(regexp = "[0-9]{12}", message = "Incorrect format of GOVT ID")
	@NotBlank(message = "GOVT ID is Mandatory")
	private String govtId;

	// @JsonIgnore
	@Column(name = "PASSWORD")
	//@Pattern(regexp = "[A-Za-z0-9+_.-]{9}", message = "Incorrect format of Password")
	//@NotBlank(message = "Password is Mandatory")
	private String password;

	@Min(value = 300, message = "Score can't be less than 400.")
	@Max(value = 850, message = "Score can't be less than 850.")
	@Column(name = "CREDIT_SCORE")
	private int creditScore;

	@Embedded
	@Column(name = "ADDRESS")
	private Address address;

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getPhoneNumber() {
		return phoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getGovtId() {
		return govtId;
	}

	public void setGovtId(String govtId) {
		this.govtId = govtId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getCreditScore() {
		return creditScore;
	}

	public void setCreditScore(int creditScore) {
		this.creditScore = creditScore;
	}

}
