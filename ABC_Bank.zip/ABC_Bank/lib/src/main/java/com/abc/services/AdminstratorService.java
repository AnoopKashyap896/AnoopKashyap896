package com.abc.services;
import java.util.List;


import com.abc.entities.LoanDetails;


public interface AdminstratorService {

		public void addLoanDetails(LoanDetails loanDetails);
		public LoanDetails updateLoanDetails(LoanDetails loanDetails);
		public void removeLoanDetails(int LoanId);
		public List<LoanDetails> findAllLoanDetails();
		public LoanDetails getLoanById(int loanId);
//		public boolean updateLoanDetails1(LoanDetails loanDetails);
	}

