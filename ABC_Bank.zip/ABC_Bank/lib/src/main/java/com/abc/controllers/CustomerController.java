package com.abc.controllers;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.abc.entities.ApplicationForm;
import com.abc.entities.Customer;
import com.abc.entities.EMI;
import com.abc.entities.Employee;
import com.abc.entities.LoanDetails;
import com.abc.entities.LoanFileStatus;
import com.abc.exceptions.NoSuchApplicationException;
import com.abc.exceptions.NoSuchCustomerException;
import com.abc.exceptions.NoSuchEMI;
import com.abc.services.AdminstratorService;
import com.abc.services.ApplicationFormService;
import com.abc.services.CustomerService;

@CrossOrigin
@RestController
@RequestMapping(path = "customers")
public class CustomerController {

	@Autowired
	private CustomerService service = null;

	@Autowired
	private AdminstratorService service1 = null;
	
	@Autowired
	private ApplicationFormService service2 = null;
	
	

	// http://localhost:9090/abc-api/customers/applicationform ->method:post
	@PostMapping(path="/applicationform")
	public ResponseEntity<String> fillApplicationForm(@RequestBody ApplicationForm applicationform) {

		ResponseEntity<String> response = null;
		applicationform.setStatus(LoanFileStatus.INITIALIZED);
		service2.addApplicationForm(applicationform);

		if (applicationform.getApplicationId() != 0) {
			response = new ResponseEntity<String>(applicationform.getApplicationId() + " is created in the database.",
					HttpStatus.CREATED);
		}
		return response;
	}

	// http://localhost:9090/abc-api/customers ->method:get
	@GetMapping
	public List<Customer> getAllCustomers() {
		return service.findAllCustomers();
	}

	// http://localhost:9090/abc-api/customers/getCustomerById ->method:get
	@GetMapping(path = "/getCustomerById")
	public Customer getCustomerById(Integer customerId) throws NoSuchCustomerException {
		return service.getCustomerById(customerId);
	}

	// http://localhost:9090/abc-api/customers/viewLoanDetails ->method:get
	@GetMapping(path = "viewLoanDetails")
	public List<LoanDetails> ViewLoanPlans() {
		return service1.findAllLoanDetails();
	}

	// http://localhost:9090/abc-api/customers ->method:post
	@PostMapping
	public ResponseEntity<String> registerCustomer(@Valid @RequestBody Customer customer) {

		ResponseEntity<String> response = null;
		service.addCustomer(customer);

		if (customer.getCustomerId() != 0) {
			response = new ResponseEntity<String>(customer.getCustomerId() + " is created in the database.",
					HttpStatus.CREATED);
		}
		return response;
	}

	// http://localhost:9090/abc-api/customers/UpdateCustomerInfo ->method:put
	@PutMapping(path = "UpdateCustomerInfo")
	public ResponseEntity<Customer> updateCustomerInfo(@RequestBody Customer Customer) {
		Customer = service.updateCustomerInfo(Customer);
		ResponseEntity<Customer> response = new ResponseEntity<Customer>(Customer, HttpStatus.OK);
		return response;
	}

	// http://localhost:9090/abc-api/customers/login ->method:get
	@PostMapping(path = "login")
	public ResponseEntity<String> checkLogin(@RequestBody Customer customer) {
		ResponseEntity<String> response = null;
		boolean result = service.customerLogin(customer);
		if(result) {
			response = new ResponseEntity<String>("Username and Password is correct", HttpStatus.OK);
		}else {
			response = new ResponseEntity<String>("Username and Password is incorrect", HttpStatus.INTERNAL_SERVER_ERROR);
		}
		return response;
	}

	// http://localhost:9090/abc-api/customers/payingEmi ->method:get
	@GetMapping(path = "/payingEmi")
	public String payEMI(int emiId) throws NoSuchEMI {
		return service.updateEMI(emiId);

	}

	// http://localhost:9090/abc-api/customers/viewActiveEmi ->method:get
	@GetMapping(path = "/ViewActiveEmi")
	public List<EMI> checkActiveEmi(Integer customerId) throws NoSuchCustomerException {
		return service.checkActiveEmi(customerId);

	}

	// http://localhost:9090/abc-api/customers/viewById ->method:get
	@GetMapping(path = "/viewById")
	public ApplicationForm getApplicationFormById(int applicationId) throws NoSuchApplicationException {
		return service.findApplicationById(applicationId);
	}

	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(MethodArgumentNotValidException ex) {
		Map<String, String> errors = new HashMap<>();
		ex.getBindingResult().getAllErrors().forEach((error) -> {
			String fieldName = ((FieldError) error).getField();
			String errorMessage = error.getDefaultMessage();
			errors.put(fieldName, errorMessage);
		});
		return errors;

	}

}
