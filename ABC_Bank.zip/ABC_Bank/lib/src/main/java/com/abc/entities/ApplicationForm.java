package com.abc.entities;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

import com.abc.converters.LoanFileStatusConverter;

@Entity
@Table(name = "APPLICATION_FORM")
public class ApplicationForm {
	@Id
	@Column(name = "APPLICATION_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int applicationId;

	@Column
	private LocalDate createdDate;

	@ManyToOne(targetEntity = LoanDetails.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "LOAN_ID") // here
	private LoanDetails loanId;

	@Column(name = "LOAN_AMOUNT")
	private int loanAmount;

	@Min(value = 24, message = "must be greater than or equal to 24")
	@Max(value = 240, message = "must be lesser than or equal to 240")
	@Column(name = "LOAN_TERM")
	private int loanTerm;

	@ManyToOne(targetEntity = Employee.class)
	@JoinColumn(name = "updatedBy")
	private Employee updatedBy;

	public LocalDate getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDate createdDate) {
		this.createdDate = createdDate;
	}

	

	public LoanDetails getLoanId() {
		return loanId;
	}

	public void setLoanId(LoanDetails loanId) {
		this.loanId = loanId;
	}

	public Employee getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Employee updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Column
	@Convert(converter = LoanFileStatusConverter.class)
	private LoanFileStatus status = LoanFileStatus.INITIALIZED;

	public LoanFileStatus getStatus() {
		return status;
	}

	public void setStatus(LoanFileStatus status) {
		this.status = status;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public int getApplicationId() {
		return applicationId;
	}

	@ManyToOne(targetEntity = Customer.class) // here
	@JoinColumn(name = "CUSTOMER_ID") // here
	private Customer customer; // here

	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}

	public int getLoanAmount() {
		return loanAmount;
	}

	public void setLoanAmount(int loanAmount) {
		this.loanAmount = loanAmount;
	}

	public int getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}

	@Override
	public String toString() {
		return "ApplicationForm [applicationId=" + applicationId + ", createdDate=" + createdDate + ", loanId=" + loanId
				+ ", loanAmount=" + loanAmount + ", loanTerm=" + loanTerm + ", updatedBy=" + updatedBy + ", status="
				+ status + ", customer=" + customer + "]";
	}

	

}
