package com.abc.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.daos.ApplicationFormDao;
import com.abc.daos.EmiDao;
import com.abc.daos.EmployeeDao;
import com.abc.entities.ApplicationForm;
import com.abc.entities.Customer;
import com.abc.entities.EMI;
import com.abc.entities.Employee;
import com.abc.entities.LoanDetails;
import com.abc.exceptions.NoSuchApplicationException;

@Service
public class ApplicationFormServiceImpl implements ApplicationFormService {

	@Autowired
	private ApplicationFormDao dao = null;

	@Autowired
	private EmiDao dao1 = null;
	
	@Autowired
	private EmployeeDao dao2 = null;

	@Transactional
	public void addApplicationForm(ApplicationForm applicationform) {
		dao.save(applicationform);
		Employee employee = dao2.getOne(99);
		applicationform.setUpdatedBy(employee);
	}

	@Override
	public List<ApplicationForm> findAllApplicationForm() {

		return dao.findAll();
	}

	// Method to calculate EMI for the application and store in EMI table
	public EMI calculateEMI(int ApplicationId) {
		ApplicationForm application = dao.getOne(ApplicationId);
		double principle = application.getLoanAmount();
		LoanDetails loanId = application.getLoanId();
		int LoanTerm = application.getLoanTerm();
		Customer customer = application.getCustomer();
		// LoanDetails loan = dao.findById(loanId);
		double interestRate = loanId.getInterestRate();
		interestRate = interestRate / (12 * 100);
		double emi = Math.round((principle * interestRate * Math.pow(1 + interestRate, LoanTerm))
				/ (Math.pow(1 + interestRate, LoanTerm) - 1));
		System.out.println(emi);
		EMI emi1 = new EMI();
		emi1.setCustomerId(customer);
		emi1.setLoanTerm(LoanTerm);
		emi1.setMonthlyPayment(emi);
		emi1.setRemainingTerm(LoanTerm);
		return dao1.save(emi1);

	}

	// Method to find the application by their Id
	@Override
	public ApplicationForm findApplicationById(int applicationId) throws NoSuchApplicationException {
		try {
			Optional<ApplicationForm> application = dao.findById(applicationId);
			if (application.get() != null) {
				return application.get();
			}
		} catch (NoSuchElementException e) {
			throw new NoSuchApplicationException("ApplicationForm with id " + applicationId + " is not found.");
		}
		return null;
	}

}
