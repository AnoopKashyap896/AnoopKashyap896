package com.abc.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.daos.AdministratorDao;
import com.abc.daos.ApplicationFormDao;
import com.abc.daos.CustomerDao;
import com.abc.daos.EmiDao;
import com.abc.entities.ApplicationForm;
import com.abc.entities.Customer;
import com.abc.entities.EMI;
import com.abc.entities.Employee;
import com.abc.entities.LoanDetails;
import com.abc.exceptions.NoSuchApplicationException;
import com.abc.exceptions.NoSuchCustomerException;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerDao dao = null;

	@Autowired
	private AdministratorDao dao1 = null;

	@Autowired
	private EmiDao dao2 = null;

	@Autowired
	private ApplicationFormDao dao3 = null;

	// Method to Register new Customer
	@Transactional
	public Customer addCustomer(Customer customer) {
		return dao.save(customer);
	}

	public List<Customer> findAllCustomers() {
		return dao.findAll();
	}

	// Method to view complete details of customer by using customer Id
	public Customer getCustomerById(Integer customerId) throws NoSuchCustomerException {
		try {
			Optional<Customer> customer = dao.findById(customerId);
			if (customer.get() != null) {
				return customer.get();
			}
		} catch (NoSuchElementException e) {
			throw new NoSuchCustomerException("Customer with id " + customerId + " is not found.");
		}
		return null;
	}

	// Method to view all the loan Plans offered to customer
	@Override
	public List<LoanDetails> getLoanDetails() {
		return dao1.findAll();
	}

	// Method to view complete details of customer's application form using the
	// application Id
	public ApplicationForm findApplicationById(int applicationId) throws NoSuchApplicationException {
		try {
			Optional<ApplicationForm> application = dao3.findById(applicationId);
			if (application.get() != null) {
				return application.get();
			}
		} catch (NoSuchElementException e) {
			throw new NoSuchApplicationException("ApplicationForm with id " + applicationId + " is not found.");
		}
		return null;
	}

	// Method to Login for the customer
	public boolean customerLogin(Customer customer) {
		boolean result=false;
		Customer customer1= dao.findcustomerName(customer.getCustomerId(),customer.getPassword()) ;  

		if (customer1 != null) {
			result=true;
		}
			return result;
	}


	// Method to pay EMI
	@Override
	public String updateEMI(int emiId) {
		EMI emi = dao2.getOne(emiId);
		int Term = emi.getRemainingTerm();
		if (Term == 0) {
			return "EMI Payment is completed.";
		}
		emi.setRemainingTerm(Term - 1);
		dao2.save(emi);
		return "Your EMI for the month is: " + emi.getMonthlyPayment() + "\n Remaining Term is "
				+ emi.getRemainingTerm() + " months.";
	}

	// Method to Update CustomerInfo
	@Override
	public Customer updateCustomerInfo(Customer customer) {
		return dao.save(customer);
	}

	// Method to List out Active EMI's w.r.t to Customer Id
	@Override
	public List<EMI> checkActiveEmi(Integer customerId) throws NoSuchCustomerException {
		try {
			Optional<Customer> customer = dao.findById(customerId);
			if (customer.get() != null) {
				List<EMI> emi = dao.findActiveEmi(customerId);
				return emi;
			}
		} catch (NoSuchElementException e) {
			throw new NoSuchCustomerException(
					"Customer with id " + customerId + " is not found and has no active EMI available.");
		}
		return null;
	}

}
