package com.abc.entities;

public enum LoanFileStatus {
	INITIALIZED(0), UNDER_CONSIDERATION(1), APPROVED(2), REJECTED(3),;

	private Integer dbValue;

	LoanFileStatus(int dbValue) {
		this.dbValue = dbValue;
	}

	public Integer getDbValue() {
		return this.dbValue;
	}

	public static LoanFileStatus getLoanFileStatus(int dbValue) {
		switch (dbValue) {
		case 0:
			return INITIALIZED;
		case 1:
			return UNDER_CONSIDERATION;
		case 2:
			return APPROVED;
		case 3:
			return REJECTED;
		default:
			throw new IllegalArgumentException("Unknown " + dbValue);
		}
	}
}