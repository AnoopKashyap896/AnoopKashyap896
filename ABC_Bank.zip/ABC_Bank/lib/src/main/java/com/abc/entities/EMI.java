package com.abc.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class EMI implements Serializable {

	@Id
	@Column(name = "EMI_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int emiId;

	@ManyToOne(targetEntity = Customer.class, fetch = FetchType.LAZY)
	@JoinColumn(name = "CUSTOMER_ID")
	private Customer customerId;

	@Column(name = "LOAN_TERM")
	@Min(value = 24)
	@Max(value = 240)
	private int loanTerm;

	@Column(name = "REMAINING_TERM")
	private int remainingTerm;

	@Column(name = "MONTHLY_PAYMENT")
	private double monthlyPayment;

	public Customer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Customer customerId) {
		this.customerId = customerId;
	}

	public int getLoanTerm() {
		return loanTerm;
	}

	public void setLoanTerm(int loanTerm) {
		this.loanTerm = loanTerm;
	}

	public double getMonthlyPayment() {
		return monthlyPayment;
	}

	public void setMonthlyPayment(double monthlyPayment) {
		this.monthlyPayment = monthlyPayment;
	}

	public int getEmiId() {
		return emiId;
	}

	public void setEmiId(int emiId) {
		this.emiId = emiId;
	}

	public int getRemainingTerm() {
		return remainingTerm;
	}

	public void setRemainingTerm(int remainingTerm) {
		this.remainingTerm = remainingTerm;
	}

	@Override
	public String toString() {
		return "EMI [emiId=" + emiId + ", customerId=" + customerId + ", loanTerm=" + loanTerm + ", remainingTerm="
				+ remainingTerm + ", monthlyPayment=" + monthlyPayment + "]";
	}

}