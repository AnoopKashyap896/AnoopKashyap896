package com.abc.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "EMPLOYEE")
public class Employee {
	@Id
	@Column(name = "EMP_ID")
	private int empId;

	@Column(name = "EMP_NAME", length = 20)
	@NotBlank(message = "Employee Name is Mandatory")
	private String empName;

	@Column(name = "EMAIL_ID")
	@Pattern(regexp = "[A-Za-z0-9+_.-]+@(.+)", message = "Incorrect Format of Email ID")
	@NotBlank(message = "Email ID is Mandatory")
	private String emailId;

	
	@Pattern(regexp = "[A-Za-z0-9+_.-]{9}", message = "Incorrect format of Password")
	@NotBlank(message = "Password is Mandatory")
	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "DEPARTMENT", length = 6)
	@NotBlank(message = "Department Name is Mandatory")
	private String department;

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", emailId=" + emailId + ", password=" + password
				+ ", department=" + department + "]";
	}

}