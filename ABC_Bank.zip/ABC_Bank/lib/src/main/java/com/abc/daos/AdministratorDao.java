package com.abc.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.abc.entities.LoanDetails;

public interface AdministratorDao extends JpaRepository<LoanDetails, Integer> {
	
//	@Modifying
//	@Query(value="Update LoanDetails s Set s.interestRate = :rate, s.loanType = :type Where s.loanId = :id")
//	public int updateLoanDetails1(@Param("rate") double interestRate, @Param("type") String loanType, @Param("id") int loanId);

}
