package com.abc.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.abc.entities.ApplicationForm;

@Repository
public interface ApplicationFormDao extends JpaRepository<ApplicationForm, Integer> {

}
