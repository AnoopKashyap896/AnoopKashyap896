package com.abc.services;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.daos.ApplicationFormDao;
import com.abc.daos.EmployeeDao;
import com.abc.daos.LADdao;
import com.abc.entities.ApplicationForm;
import com.abc.entities.Customer;
import com.abc.entities.Employee;
import com.abc.entities.LoanDetails;
import com.abc.entities.LoanFileStatus;
import com.abc.exceptions.NoSuchApplicationException;

@Service
public class LADServiceImpl implements LADService {

	@Autowired
	private LADdao dao = null;

	@Autowired
	private ApplicationFormDao dao2 = null;

	@Autowired
	private EmployeeDao dao3 = null;

	@Override
	public List<ApplicationForm> findAllApplicationForm() {
		return dao.findAll();
	}

	// Method to view and verify application details
	@Override
	public ApplicationForm findApplicationById(int applicationId) throws NoSuchApplicationException {
		try {
			Optional<ApplicationForm> application = dao.findById(applicationId);
			if (application.get() != null) {
				return application.get();
			}
		} catch (NoSuchElementException e) {
			throw new NoSuchApplicationException("ApplicationForm with id " + applicationId + " is not found.");
		}
		return null;
	}

	// method to check the loan eligibility and update the status of the application
	@Override
	public void loanEligilbility(int applicationId, int empId) {
		ApplicationForm application = dao2.getOne(applicationId);
		Customer customer1 = application.getCustomer();
		double salary1 = customer1.getSalary();
		int creditSCORE = customer1.getCreditScore();
		int amt = application.getLoanAmount();
		Employee emp = dao3.getOne(empId);
		application.setUpdatedBy(emp);
		LoanDetails Loan=application.getLoanId();
		double interestrate1=Loan.getInterestRate();
		int loanterm1 = application.getLoanTerm();
		if (((salary1 / 12) * 27 + ((interestrate1/100) * amt) > amt) && creditSCORE > 500) {
			application.setStatus(LoanFileStatus.APPROVED);
		} else if (((salary1 / 12) * 27 + ((interestrate1/100) * amt) > amt) && creditSCORE < 500) {
			application.setStatus(LoanFileStatus.UNDER_CONSIDERATION);
		} else {
			application.setStatus(LoanFileStatus.REJECTED);
		}

		dao2.save(application);

	}

}
