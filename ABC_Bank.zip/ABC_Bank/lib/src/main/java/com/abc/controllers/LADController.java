package com.abc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.entities.ApplicationForm;
import com.abc.entities.EMI;
import com.abc.exceptions.NoSuchApplicationException;
import com.abc.services.ApplicationFormService;
import com.abc.services.LADService;

@CrossOrigin
@RestController
@RequestMapping(path = "viewApplications")
public class LADController {

	@Autowired
	private ApplicationFormService service = null;

	@Autowired
	private LADService service1 = null;

	// http://localhost:9090/abc-api/viewApplications
	@GetMapping
	public List<ApplicationForm> getAllApplicationForm() {
		return service.findAllApplicationForm();
	}

	// http://localhost:9090/abc-api/viewApplications/viewById
	@GetMapping(path = "/viewById")
	public ApplicationForm getApplicationFormById(int applicationId) throws NoSuchApplicationException {
		return service.findApplicationById(applicationId);
	}
	
	// http://localhost:9090/abc-api/viewApplications/emi
	@GetMapping(path = "/emi")
	public EMI calculateEMI(int applicationId) {
		return service.calculateEMI(applicationId);
	}
	
	// http://localhost:9090/abc-api/viewApplications/getLoanStatusById
	@GetMapping(path = "/getLoanStatusById")
	public void loanEligilbility(int applicationId, int empId) {
		service1.loanEligilbility(applicationId, empId);
	}
}
