package com.abc.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity

@Table(name = "LOAN_DETAILS")
public class LoanDetails {
	@Id
	@Column(name = "LOAN_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int LoanId;

	@Column(name = "LOAN_TYPE")
	private String loanType;

	@Column(name = "INTEREST_RATE")
	private double interestRate;

	public int getLoanId() {
		return LoanId;
	}

	public void setLoanId(int loanId) {
		LoanId = loanId;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public double getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(double interestRate) {
		this.interestRate = interestRate;
	}

	@Override
	public String toString() {
		return "LoanDetails [LoanId=" + LoanId + ", loanType=" + loanType + ", interestRate=" + interestRate + "]";
	}
}
