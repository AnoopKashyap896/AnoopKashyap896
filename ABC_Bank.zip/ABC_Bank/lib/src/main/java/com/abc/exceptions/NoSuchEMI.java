package com.abc.exceptions;

public class NoSuchEMI extends Exception{
	public NoSuchEMI(String msg) {
		super(msg);
	}

}
