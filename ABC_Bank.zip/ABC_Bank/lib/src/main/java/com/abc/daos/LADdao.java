package com.abc.daos;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.entities.ApplicationForm;

@Repository
public interface LADdao extends JpaRepository<ApplicationForm, Integer> {

	@Query(value = "select a from ApplicationForm a where a.status =:status")
	List<ApplicationForm> findApplicationStatus(@Param("status") int dbValue);
}
