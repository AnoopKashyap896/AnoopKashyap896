package com.abc.entities;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotBlank;

@Embeddable
public class Address {

	@Column(name = "HOUSE_Number", length = 3)
	@NotBlank(message = "House Number is Mandatory")
	private int houseNumber;

	@Column(name = "STREET_NAME", length = 30)
	@NotBlank(message = "Street Name is Mandatory")
	private String streetName;

	@Column(name = "AREA", length = 40)
	@NotBlank(message = "AREA is Mandatory")
	private String area;

	@Column(name = "CITY", length = 50)
	@NotBlank(message = "City Name is Mandatory")
	private String city;

	@Column(name = "STATE", length = 50)
	@NotBlank(message = "State Name is Mandatory")
	private String state;

	@Column(name = "PINCODE", length = 6)
	@NotBlank(message = "Pincode is Mandatory")
	private String pinCode;

	public int getHouseNumber() {
		return houseNumber;
	}

	public void setHouseNumber(int houseNumber) {
		this.houseNumber = houseNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public String getArea() {
		return area;
	}

	public void setArea(String area) {
		this.area = area;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	@Override
	public String toString() {
		return "Address [houseNumber=" + houseNumber + ", streetName=" + streetName + ", area=" + area + ", city="
				+ city + ", state=" + state + ", pinCode=" + pinCode + "]";
	}

	
}
