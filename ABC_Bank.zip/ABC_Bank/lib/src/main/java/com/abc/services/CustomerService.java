package com.abc.services;

import java.util.List;
import com.abc.entities.ApplicationForm;
import com.abc.entities.Customer;
import com.abc.entities.EMI;
import com.abc.entities.LoanDetails;
import com.abc.exceptions.NoSuchApplicationException;
import com.abc.exceptions.NoSuchCustomerException;
import com.abc.exceptions.NoSuchEMI;

public interface CustomerService {
	public Customer addCustomer(Customer customer);

	public List<Customer> findAllCustomers();

	public Customer getCustomerById(Integer customerId) throws NoSuchCustomerException;

	public List<LoanDetails> getLoanDetails();

	public boolean customerLogin(Customer customer);

	public String updateEMI(int emiId) throws NoSuchEMI;

	public ApplicationForm findApplicationById(int applicationId) throws NoSuchApplicationException;

	public Customer updateCustomerInfo(Customer customer);

	public List<EMI> checkActiveEmi(Integer customerId) throws NoSuchCustomerException;
}
