package com.abc.controllers;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.entities.Employee;
import com.abc.services.EmployeeService;


@RestController
@RequestMapping(path = "employees")
@CrossOrigin
public class EmployeeController {

	@Autowired
	private EmployeeService service = null;

	// http://localhost:9090/customer-api/loantypes -->method:get
	@GetMapping
	public Optional<Employee> FindEmployeeById(int empId) {
		return service.getEmployeeById(empId);
	}

	// http://localhost:9090/customer-api/loantypes
	@PostMapping
	public ResponseEntity<String> addEmployee(@RequestBody Employee employee) {

		ResponseEntity<String> response = null;
		service.addEmployee(employee);

		if (employee.getEmpId() != 0) {
			response = new ResponseEntity<String>(employee.getEmpId() + " is created in the database.",
					HttpStatus.CREATED);
		}
		return response;
	}

	@PutMapping
	public ResponseEntity<Employee> updateEmployee(@RequestBody Employee employee) {
		employee = service.updateEmployee(employee);
		ResponseEntity<Employee> response = new ResponseEntity<Employee>(employee, HttpStatus.OK);
		return response;
	}

	// http://localhost:9090/abc-api/employees/adminLogin
    @PostMapping(path = "adminLogin")
    public ResponseEntity<String> adminLogin(@RequestBody Employee employee) {
        ResponseEntity<String> response = null;
        boolean result = service.adminLogin(employee);
        if(result) {
            response = new ResponseEntity<String>("Username and Password is correct", HttpStatus.OK);
        }else {
            response = new ResponseEntity<String>("Username and Password is incorrect", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return response;
    }

    // http://localhost:9090/abc-api/employees/ladLogin
        @PostMapping(path = "ladLogin")
        public ResponseEntity<String> ladLogin(@RequestBody Employee employee) {
            ResponseEntity<String> response = null;
            boolean result = service.ladLogin(employee);
            if(result) {
                response = new ResponseEntity<String>("Username and Password is correct", HttpStatus.OK);
            }else {
                response = new ResponseEntity<String>("Username and Password is incorrect", HttpStatus.INTERNAL_SERVER_ERROR);
            }
            return response;
        }
}
