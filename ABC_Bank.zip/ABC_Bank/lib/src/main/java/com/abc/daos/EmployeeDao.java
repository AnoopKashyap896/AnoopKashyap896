package com.abc.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.entities.Employee;
@Repository
public interface EmployeeDao extends JpaRepository<Employee, Integer> {

	@Query(value = "select u from Employee u where u.empId=:empId And u.password=:password And u.department=:department")
    public Employee findEmployeeName(@Param("empId") int empId, @Param("password") String password, @Param("department") String department);

	
}
