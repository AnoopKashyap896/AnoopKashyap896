package com.abc.services;

import java.util.List;

import com.abc.entities.ApplicationForm;
import com.abc.exceptions.NoSuchApplicationException;

public interface LADService {
	public List<ApplicationForm> findAllApplicationForm();

	public ApplicationForm findApplicationById(int applicationId) throws NoSuchApplicationException;;

	public void loanEligilbility(int applicationId, int empId);
}
