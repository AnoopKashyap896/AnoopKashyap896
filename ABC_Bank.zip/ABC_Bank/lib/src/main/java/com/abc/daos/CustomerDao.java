package com.abc.daos;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.abc.entities.Customer;
import com.abc.entities.EMI;

@Repository
public interface CustomerDao extends JpaRepository<Customer, Integer> {

	@Query(value = "select u from Customer u where u.customerId=:customerId And u.password=:password")
	public Customer findcustomerName(@Param("customerId") int customerId, @Param("password") String password);

	@Query("SELECT e FROM EMI e WHERE e.customerId.customerId =:customerId")
	public List<EMI> findActiveEmi(@Param("customerId") Integer customerId);

}
