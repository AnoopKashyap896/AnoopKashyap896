package com.abc.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import com.abc.entities.EMI;

public interface EmiDao extends JpaRepository<EMI, Integer> {

}
