package com.abc.services;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.daos.AdministratorDao;

import com.abc.entities.LoanDetails;


@Service
public class AdministratorServiceImpl implements AdminstratorService {

	@Autowired
	private AdministratorDao dao = null;

	@Transactional
	public void addLoanDetails(LoanDetails loanDetails) {
		dao.save(loanDetails);
	}

	public List<LoanDetails> findAllLoanDetails() {
		return dao.findAll();
	}

	@Override
	public LoanDetails updateLoanDetails(LoanDetails loanDetails) {
		return dao.save(loanDetails);
	}

	@Override
	public void removeLoanDetails(int LoanId) {
		dao.deleteById(LoanId);
	}

	@Override
	public LoanDetails getLoanById(int loanId) {
		// TODO Auto-generated method stub
		if(dao.existsById(loanId)) {
			return dao.findById(loanId).get();
		}
		return null;

	}

//	@Override
//	@Transactional
//	public boolean updateLoanDetails1(LoanDetails loanDetails) {
//		repository.updateLoanDetails1(loanDetails.getInterestRate(),loanDetails.getLoanType(),loanDetails.getLoanId());
//		return true;
//	}
	
	
	
}
