package com.abc.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.abc.entities.ApplicationForm;
import com.abc.entities.LoanFileStatus;
import com.abc.services.ApplicationFormService;

@RestController
@CrossOrigin
@RequestMapping(path = "applicationForm")
public class ApplicationFormController {

	@Autowired
	private ApplicationFormService service = null;

	// http://localhost:9090/abc-api/applicationform ->method:post
	@PostMapping
	public ResponseEntity<String> fillApplicationForm(@RequestBody ApplicationForm applicationform) {

		ResponseEntity<String> response = null;
		applicationform.setStatus(LoanFileStatus.INITIALIZED);
		
		service.addApplicationForm(applicationform);

		if (applicationform.getApplicationId() != 0) {
			response = new ResponseEntity<String>(applicationform.getApplicationId() + " is created in the database.",
					HttpStatus.CREATED);
		}
		return response;
	}

}
