package com.abc.services;

import java.util.List;
import com.abc.entities.ApplicationForm;
import com.abc.entities.EMI;
import com.abc.exceptions.NoSuchApplicationException;

public interface ApplicationFormService {

	public void addApplicationForm(ApplicationForm applicationform);

	public EMI calculateEMI(int applicationId);

	public List<ApplicationForm> findAllApplicationForm();

	public ApplicationForm findApplicationById(int applicationId) throws NoSuchApplicationException;
}
