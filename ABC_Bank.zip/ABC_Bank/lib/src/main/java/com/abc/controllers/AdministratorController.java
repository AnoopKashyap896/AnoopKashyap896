package com.abc.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.abc.entities.LoanDetails;

import com.abc.services.AdminstratorService;



@CrossOrigin
@RestController
@RequestMapping(path = "loantypes")
public class AdministratorController {

	@Autowired
	private AdminstratorService service = null;

	// http://localhost:9090/abc-api/loantypes -->method:get
	@GetMapping
	public List<LoanDetails> getAllLoanDetails() {
		return service.findAllLoanDetails();
	}

	// http://localhost:9090/abc-api/loantypes
	@PostMapping
	public ResponseEntity<String> saveLoanDetails(@RequestBody LoanDetails loanDetails) {

		ResponseEntity<String> response = null;
		service.addLoanDetails(loanDetails);

		if (loanDetails.getLoanId() != 0) {
			response = new ResponseEntity<String>(loanDetails.getLoanId() + " is created in the database.",
					HttpStatus.CREATED);
		}
		return response;
	}

	// http://localhost:9090/abc-api/loantypes
	@PutMapping
	
	public ResponseEntity<LoanDetails> updateLoanDetails(@RequestBody LoanDetails loanDetails) {
		loanDetails = service.updateLoanDetails(loanDetails);
		ResponseEntity<LoanDetails> response = new ResponseEntity<LoanDetails>(loanDetails, HttpStatus.OK);
		return response;
	}

	@DeleteMapping(path = "{LoanId}")
	public void removeLoanDetails(@PathVariable("LoanId") int LoanId) {
		service.removeLoanDetails(LoanId);
	}
	
	
//	
//	public LoanDetails getLoanById(@PathVariable("loanId") int loanId) {
//		return service.getLoanById(loanId);
//	}
	
	
	// http://localhost:9090/abc-api/loantypes/getLoanById/
	@GetMapping(path = "/getLoanById/")
	public ResponseEntity<LoanDetails> getLoanById(@PathVariable("loanId") int loanId){	
		ResponseEntity<LoanDetails> response = null;
		LoanDetails loandetails = service.getLoanById(loanId);
		response = new ResponseEntity<LoanDetails>(loandetails, HttpStatus.OK);
		return response;
	}
	

}
