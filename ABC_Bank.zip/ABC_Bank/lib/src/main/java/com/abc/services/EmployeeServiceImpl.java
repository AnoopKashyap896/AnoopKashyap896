package com.abc.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.abc.daos.EmployeeDao;
import com.abc.entities.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao = null;

	@Override
	public void addEmployee(Employee employee) {
		dao.save(employee);
	}

	@Override
	public Employee updateEmployee(Employee employee) {
		return dao.save(employee);
	}

	// Method for Employee to Login
	@Override
    public boolean adminLogin(Employee employee) {
        boolean result = false;
        Employee employee1 = dao.findEmployeeName(employee.getEmpId(),employee.getPassword(),employee.getDepartment());
        if (employee1 != null) {
            return true;
        } 
        return result;
    }
    @Override
    public boolean ladLogin(Employee employee) {
        boolean result = false;
        Employee employee1 = dao.findEmployeeName(employee.getEmpId(),employee.getPassword(),employee.getDepartment());
        if (employee1 != null) {
            return true;
        } 
        return result;
    }

	@Override
	public Optional<Employee> getEmployeeById(int empId) {
		return dao.findById(empId);
	}

}
