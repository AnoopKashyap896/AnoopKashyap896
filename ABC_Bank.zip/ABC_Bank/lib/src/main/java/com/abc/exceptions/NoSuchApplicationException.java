package com.abc.exceptions;

public class NoSuchApplicationException extends Exception {
	public NoSuchApplicationException(String message) {
		super(message);
	}

}
